public class Ex1 {

    public static void main (String[] args) {

	// this is a line comment

	/* this is a regular comment
	   // hi there
	   this is the end of the regular comment */

	int i;

	i = (3+4) * (5+6);
	System.out.print ("The result is \n\n" + i);

    }
}
	